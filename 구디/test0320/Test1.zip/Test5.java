package test0320;
/*
 * 1부터 100까지의 숫자 중 2의 배수이거나, 3의 배수의 합을 구하기 
 */
public class Test5 {
	public static void main(String[] args) {
		int sum = 0;
		for (int i = 2; i < 101; i += 2) {
			sum += i;
		} 
		for (int j = 3; j < 101; j += 3) {
			sum += j;
		}

		System.out.println(sum);
		
	}
}